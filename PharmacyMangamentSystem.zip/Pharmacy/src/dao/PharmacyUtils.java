package dao;

public class PharmacyUtils {
    public static String billPath = "D:\\PharmacyBills\\"; 
    
    // Other utility methods...
}
